package com.example.controller;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PaginaController {

    @GetMapping("/")
    public String inicio() {
        return "forward:/index.html";   // ← ESTA LÍNEA SOLUCIONA EL 500
    }

    @GetMapping("/ejercicios")
    public String ejercicios() {
        return "forward:/ejercicios.html";
    }

    @GetMapping("/planes")
    public String planes() {
        return "forward:/planes.html";
    }
}