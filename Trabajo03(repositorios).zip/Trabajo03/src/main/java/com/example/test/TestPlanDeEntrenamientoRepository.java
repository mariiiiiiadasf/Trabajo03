package com.example.test;

import com.example.entities.PlanDeEntrenamiento;
import com.example.repositories.PlanDeEntrenamientoRepository;

public class TestPlanDeEntrenamientoRepository {
    public static void main(String[] args) {
        PlanDeEntrenamientoRepository planRepo = new PlanDeEntrenamientoRepository();

        //crear y guardar un nuevo plan de entrenamiento
        PlanDeEntrenamiento plan = new PlanDeEntrenamiento();
        plan.setNombre("Entrenamiento Básico");
        plan.setDescripcion("Plan para principiantes");
        plan.setDuracion(30);

        planRepo.save(plan);
        System.out.println("PlanDeEntrenamiento guardado: " + plan);

        //recuperar el plan de entrenamiento por id 
        PlanDeEntrenamiento retrievedPlan = planRepo.getById(plan.getId());
        System.out.println("PlanDeEntrenamiento recuperado: " + retrievedPlan);

        //listar todos los planes de entrenamiento 
        System.out.println("Lista de todos los PlanesDeEntrenamiento:");
        planRepo.getAll().forEach(System.out::println);

        
        //eliminar el plan de entrenamiento 
        planRepo.remove(plan);
        System.out.println("PlanDeEntrenamiento eliminado.");
    }
}