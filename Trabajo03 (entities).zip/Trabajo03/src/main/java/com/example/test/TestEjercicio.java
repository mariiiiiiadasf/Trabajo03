package com.example.test;

import com.example.entities.Ejercicio;

public class TestEjercicio {
    public static void main(String[] args) {
        System.out.println("-- Ejercicio 1 --");
        Ejercicio ejercicio = new Ejercicio(1, "Flexiones", "Baja");
        System.out.println(ejercicio);
    }
}
