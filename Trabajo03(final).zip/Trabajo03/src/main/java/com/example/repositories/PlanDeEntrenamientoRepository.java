package com.example.repositories;

import com.example.entities.PlanDeEntrenamiento;
import com.example.connectors.Connector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class PlanDeEntrenamientoRepository {
    private Connection conn = Connector.getConnection();

    public void save(PlanDeEntrenamiento plan) {
        if (plan == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO planes_de_entrenamiento (nombre, descripcion, duracion) VALUES (?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, plan.getNombre());
            ps.setString(2, plan.getDescripcion());
            ps.setInt(3, plan.getDuracion());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) plan.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(PlanDeEntrenamiento plan) {
        if (plan == null) return;
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM planes_de_entrenamiento WHERE id=?")) {
            ps.setInt(1, plan.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<PlanDeEntrenamiento> getAll() {
        List<PlanDeEntrenamiento> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM planes_de_entrenamiento")) {
            while (rs.next()) {
                list.add(new PlanDeEntrenamiento(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("descripcion"),
                        rs.getInt("duracion")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public PlanDeEntrenamiento getById(int id) {
        return getAll()
                .stream()
                .filter(p -> p.getId() == id)
                .findAny()
                .orElse(new PlanDeEntrenamiento());
    }
}