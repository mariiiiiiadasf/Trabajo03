-- Consultar todos los planes de entrenamiento
use entrenamiento;
SELECT * FROM planes_de_entrenamiento;

-- Consultar ejercicios con dificultad media
SELECT nombre FROM ejercicios WHERE dificultad = 'Media';

-- Consultar detalles de ejercicios por plan
SELECT ep.id_plan, p.nombre AS plan_nombre, e.nombre AS ejercicio_nombre, ep.cantidad, ep.peso
FROM ejercicios_planes ep
JOIN planes_de_entrenamiento p ON ep.id_plan = p.id
JOIN ejercicios e ON ep.id_ejercicio = e.id;