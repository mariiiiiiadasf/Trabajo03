-- 1. Consultar todos los planes de entrenamiento
use entrenamiento; 
SELECT * FROM planes_de_entrenamiento;

-- 2. Consultar todos los ejercicios de dificultad media
SELECT nombre FROM ejercicios WHERE dificultad = 'Media';

-- 3. Consultar detalles de ejercicios para un plan específico (por ejemplo, el plan básico)
SELECT ep.id_plan, p.nombre AS plan_nombre, e.nombre AS ejercicio_nombre, ep.cantidad, ep.peso
FROM ejercicios_planes ep
JOIN planes_de_entrenamiento p ON ep.id_plan = p.id
JOIN ejercicios e ON ep.id_ejercicio = e.id
WHERE p.nombre = 'Entrenamiento Básico';

-- 4. Consultar la cantidad total de ejercicios por plan
SELECT p.nombre AS plan_nombre, COUNT(ep.id_ejercicio) AS total_ejercicios
FROM planes_de_entrenamiento p
JOIN ejercicios_planes ep ON p.id = ep.id_plan
GROUP BY p.nombre;

-- 5. Consultar los ejercicios con el mayor peso utilizado
SELECT e.nombre, MAX(ep.peso) AS max_peso
FROM ejercicios e
JOIN ejercicios_planes ep ON e.id = ep.id_ejercicio
GROUP BY e.nombre
ORDER BY max_peso DESC;