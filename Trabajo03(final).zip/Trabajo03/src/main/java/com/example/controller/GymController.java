
package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class GymController {

    @GetMapping
    public String mostrarInicio() {
        return "index"; 
    }

    @GetMapping("/ejercicios")
    public String mostrarEjercicios() {
        return "ejercicios";
    }

    @GetMapping("/planes")
    public String mostrarPlanes() {
        return "planes";
    }

    @GetMapping("#contacto")
    public String mostrarContacto() {
        return "contacto"; 
    }
}