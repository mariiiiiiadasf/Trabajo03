-- Consultar todos los productos 
SELECT * FROM productos;

-- Consultar todas las categorías
SELECT nombre FROM categorias;