package com.example.repositories;

import com.example.connectors.Connector;
import com.example.entities.Ejercicio;
import com.example.entities.PlanDeEntrenamiento;
import com.example.entities.EjercicioPlan;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EjercicioPlanRepository {
    private Connection conn = Connector.getConnection();

    public void save(EjercicioPlan ejercicioPlan) {
        if (ejercicioPlan == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO ejercicios_planes (id_plan, id_ejercicio, cantidad, peso) VALUES (?, ?, ?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, ejercicioPlan.getPlan().getId());
            ps.setInt(2, ejercicioPlan.getEjercicio().getId());
            ps.setInt(3, ejercicioPlan.getCantidad());
            ps.setInt(4, ejercicioPlan.getPeso());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(EjercicioPlan ejercicioPlan) {
        if (ejercicioPlan == null) return;
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM ejercicios_planes WHERE id_plan=? AND id_ejercicio=?")) {
            ps.setInt(1, ejercicioPlan.getPlan().getId());
            ps.setInt(2, ejercicioPlan.getEjercicio().getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<EjercicioPlan> getAll() {
        List<EjercicioPlan> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM ejercicios_planes")) {
            while (rs.next()) {
                list.add(new EjercicioPlan(
                        new PlanDeEntrenamiento(rs.getInt("id_plan"), null, null, 0), 
                        new Ejercicio(rs.getInt("id_ejercicio"), null, null),         
                        rs.getInt("cantidad"),
                        rs.getInt("peso")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
}