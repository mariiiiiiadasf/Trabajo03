package com.example.Trabajo03;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Trabajo03ApplicationTests {

	@Test
	void contextLoads() {
	}

}
