package com.example.test;

import com.example.entities.EjercicioPlan;
import com.example.entities.Ejercicio;
import com.example.entities.PlanDeEntrenamiento;

public class TestEjercicioPlan {
    public static void main(String[] args) {
        System.out.println("-- EjercicioPlan 1 --");
        PlanDeEntrenamiento plan = new PlanDeEntrenamiento(1, "Entrenamiento Básico", "Plan para principiantes", 30);
        Ejercicio ejercicio = new Ejercicio(1, "Flexiones", "Baja");
        EjercicioPlan ejercicioPlan = new EjercicioPlan(plan, ejercicio, 10, 0);
        System.out.println(ejercicioPlan);
    }
}