package com.example.repositories;

import com.example.entities.EjercicioPlan;
//import com.example.entities.PlanDeEntrenamiento;
//import com.example.entities.Ejercicio;
import com.example.connectors.Connector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EjercicioPlanRepository {
    private Connection conn = Connector.getConnection();

    public void save(EjercicioPlan ejercicioPlan) {
        if (ejercicioPlan == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO ejercicios_planes (id_plan, id_ejercicio, cantidad, peso) " +
                        "VALUES (?, ?, ?, ?)")) {
            ps.setInt(1, ejercicioPlan.getPlan());      // id del PlanDeEntrenamiento
            ps.setInt(2, ejercicioPlan.getEjercicio());  // id del Ejercicio
            ps.setInt(3, ejercicioPlan.getCantidad());    // cantidad de repeticiones o series
            ps.setInt(4, ejercicioPlan.getPeso());        // peso utilizado
            ps.execute();                                  // ejecutar la consulta
        } catch (Exception e) {
            System.out.println("Error al guardar EjercicioPlan: " + e.getMessage());
        }
    }

    public void remove(EjercicioPlan ejercicioPlan) {
        if (ejercicioPlan == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "DELETE FROM ejercicios_planes WHERE id_plan=? AND id_ejercicio=?")) {
            ps.setInt(1, ejercicioPlan.getPlan());       // ID del plan de entrenamiento
            ps.setInt(2, ejercicioPlan.getEjercicio());   // id del ejercicio
            ps.execute();                                  // ejecutar la consulta
        } catch (Exception e) {
            System.out.println("Error al eliminar EjercicioPlan: " + e.getMessage());
        }
    }

    public List<EjercicioPlan> getAll() {
        List<EjercicioPlan> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM ejercicios_planes")) {
            while (rs.next()) {
                list.add(new EjercicioPlan(
                        rs.getInt("id_plan"),          // id del plan de entrenamiento
                        rs.getInt("id_ejercicio"),     // id del ejercicio
                        rs.getInt("cantidad"),          // cantidad
                        rs.getInt("peso")               // peso utilizado
                ));
            }
        } catch (Exception e) {
            System.out.println("Error al obtener EjercicioPlans: " + e.getMessage());
        }
        return list;
    }

    public EjercicioPlan getById(int idPlan, int idEjercicio) {
        return getAll()
                .stream()
                .filter(ep -> ep.getPlan() == idPlan && ep.getEjercicio() == idEjercicio)
                .findAny()
                .orElse(null);  // retorna null si no se encuentra
    }
}