package com.example.test;

import com.example.entities.PlanDeEntrenamiento;

public class TestPlanDeEntrenamiento {
    public static void main(String[] args) {
        System.out.println("-- PlanDeEntrenamiento 1 --");
        PlanDeEntrenamiento plan = new PlanDeEntrenamiento(1, "Entrenamiento Básico", "Plan para principiantes", 30);
        System.out.println(plan);
    }
}
