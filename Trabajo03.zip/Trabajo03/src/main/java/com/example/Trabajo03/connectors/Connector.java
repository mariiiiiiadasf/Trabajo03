package com.example.Trabajo03.connectors;

import java.sql.Connection;
import java.sql.DriverManager;

public final class Connector {

    private static Connection conn = null;

    // MariaDB
    private static String url = "jdbc:mariadb://localhost:3306/entrenamiento";
    private static String user = "root"; 
    private static String pass = ""; 

    private Connector() {}

    public static String getUrl() {
        return url;
    }

    public synchronized static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                conn = DriverManager.getConnection(url, user, pass);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return conn;
    }

    public synchronized static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (Exception e) {
            e.printStackTrace(); 
        }
    }
}