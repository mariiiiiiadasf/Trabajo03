package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Trabajo03Application {

	public static void main(String[] args) {
		SpringApplication.run(Trabajo03Application.class, args);
	}

}
