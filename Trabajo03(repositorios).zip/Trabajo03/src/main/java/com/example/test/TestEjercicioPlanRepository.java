package com.example.test;

import com.example.entities.Ejercicio;
import com.example.entities.PlanDeEntrenamiento;
import com.example.entities.EjercicioPlan;
import com.example.repositories.EjercicioPlanRepository;
import com.example.repositories.EjercicioRepository;
import com.example.repositories.PlanDeEntrenamientoRepository;

public class TestEjercicioPlanRepository {
    public static void main(String[] args) {
        EjercicioPlanRepository ejercicioPlanRepo = new EjercicioPlanRepository();
        EjercicioRepository ejercicioRepo = new EjercicioRepository();
        PlanDeEntrenamientoRepository planRepo = new PlanDeEntrenamientoRepository();

        // crear y guardar un nuevo ejercicio
        Ejercicio ejercicio = new Ejercicio();
        ejercicio.setNombre("Flexiones");
        ejercicio.setDificultad("Baja");
        ejercicioRepo.save(ejercicio);

        // crear y guardar un nuevo plan de entrenamiento
        PlanDeEntrenamiento plan = new PlanDeEntrenamiento();
        plan.setNombre("Entrenamiento Básico");
        plan.setDescripcion("Plan para principiantes");
        plan.setDuracion(30);
        planRepo.save(plan);

        // crear y guardar un nuevo ejercicio plan
        EjercicioPlan ejercicioPlan = new EjercicioPlan(plan, ejercicio, 10, 0);
        ejercicioPlanRepo.save(ejercicioPlan);
        System.out.println("EjercicioPlan guardado: " + ejercicioPlan);

        // listar todos los ejercicio plans
        System.out.println("Lista de todos los EjercicioPlans:");
        ejercicioPlanRepo.getAll().forEach(System.out::println);

        // eliminar el ejercicioplan
        ejercicioPlanRepo.remove(ejercicioPlan);
        System.out.println("EjercicioPlan eliminado.");
    }
}