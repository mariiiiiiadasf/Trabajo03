package com.example.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class EjercicioPlan {
    private PlanDeEntrenamiento plan;
    private Ejercicio ejercicio;
    private int cantidad;
    private int peso;

    public EjercicioPlan(PlanDeEntrenamiento plan, Ejercicio ejercicio, int cantidad, int peso) {
        this.plan = plan;
        this.ejercicio = ejercicio;
        this.cantidad = cantidad;
        this.peso = peso;
    }
}