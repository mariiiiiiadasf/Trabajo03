DROP TABLE IF EXISTS ejercicios_planes;
DROP TABLE IF EXISTS ejercicios;
DROP TABLE IF EXISTS planes_de_entrenamiento;

CREATE TABLE planes_de_entrenamiento (
    id INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    duracion INT,
    PRIMARY KEY (id)
);

CREATE TABLE ejercicios (
    id INT NOT NULL AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    dificultad VARCHAR(50) NOT NULL,
    PRIMARY KEY (id)
);

CREATE TABLE ejercicios_planes (
    id_plan INT,
    id_ejercicio INT,
    cantidad INT,
    peso INT,
    PRIMARY KEY (id_plan, id_ejercicio),
    FOREIGN KEY (id_plan) REFERENCES planes_de_entrenamiento(id),
    FOREIGN KEY (id_ejercicio) REFERENCES ejercicios(id)
);