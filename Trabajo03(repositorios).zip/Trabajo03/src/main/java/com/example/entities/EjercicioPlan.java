package com.example.entities;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class EjercicioPlan {
    private int plan;      
    private int ejercicio;  
    private int cantidad;  
    private int peso;      

    // constructor que acepta ids de los objetos plan de entrenamiento y ejercicio
    public EjercicioPlan(int plan, int ejercicio, int cantidad, int peso) {
        this.plan = plan;          
        this.ejercicio = ejercicio; 
        this.cantidad = cantidad;   
        this.peso = peso;           
    }
}