package com.example.test;

import com.example.entities.Ejercicio;
import com.example.repositories.EjercicioRepository;

public class TestEjercicioRepository {
    public static void main(String[] args) {
        EjercicioRepository ejercicioRepo = new EjercicioRepository();

        //crear y guardar un nuevo ejercicio
        Ejercicio ejercicio = new Ejercicio();
        ejercicio.setNombre("Flexiones");
        ejercicio.setDificultad("Baja");

        ejercicioRepo.save(ejercicio);
        System.out.println("Ejercicio guardado: " + ejercicio);

        //recuperar el ejercicio por id
        Ejercicio retrievedEjercicio = ejercicioRepo.getById(ejercicio.getId());
        System.out.println("Ejercicio recuperado: " + retrievedEjercicio);

        //listar todos los ejercicios
        System.out.println("Lista de todos los Ejercicios:");
        ejercicioRepo.getAll().forEach(System.out::println);

        // eliminar el ejercicio
        ejercicioRepo.remove(ejercicio);
        System.out.println("Ejercicio eliminado.");
    }
}