package com.example.Trabajo03.test;

import java.sql.Connection;
import java.sql.ResultSet;
import com.example.Trabajo03.connectors.Connector;

public class TestConnector {
    public static void main(String[] args) {
        try (Connection conn = Connector.getConnection()) {
            ResultSet rs = conn
                                .createStatement()
                                .executeQuery("SELECT 'Conectado'");
            if (rs.next()) {
                System.out.println(rs.getString(1));
            } else {
                System.out.println("No Conectado");
            }
        } catch (Exception e) {
            e.printStackTrace(); 
            System.out.println("No Conectado");
        }
    }
}