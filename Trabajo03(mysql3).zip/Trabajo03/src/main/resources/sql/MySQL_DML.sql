-- Insertar datos en la tabla de planes de entrenamiento
use entrenamiento;
INSERT INTO planes_de_entrenamiento (nombre, descripcion, duracion) VALUES 
('Entrenamiento Básico', 'Plan básico para principiantes', 30),
('Entrenamiento Avanzado', 'Plan avanzado para expertos', 60);

-- Insertar datos en la tabla de ejercicios
INSERT INTO ejercicios (nombre, dificultad) VALUES 
('Flexiones', 'Baja'),
('Sentadillas', 'Media'),
('Dominadas', 'Alta');

-- Insertar datos en la tabla de ejercicios_planes
INSERT INTO ejercicios_planes (id_plan, id_ejercicio, cantidad, peso) VALUES 
(1, 1, 10, 0),  -- 10 flexiones con peso 0 para el plan básico
(1, 2, 15, 0),  -- 15 sentadillas con peso 0 para el plan básico
(2, 2, 20, 10), -- 20 sentadillas con 10 kg para el plan avanzado
(2, 3, 5, 20);  -- 5 dominadas con 20 kg para el plan avanzado