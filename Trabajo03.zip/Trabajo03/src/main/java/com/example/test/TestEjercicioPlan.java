package com.example.test;

import com.example.entities.EjercicioPlan;

public class TestEjercicioPlan {
    public static void main(String[] args) {
        System.out.println("-- EjercicioPlan 1 --");
        
        int planId = 1; 
        int ejercicioId = 1; 
        
        EjercicioPlan ejercicioPlan = new EjercicioPlan(planId, ejercicioId, 10, 0);
        
        System.out.println(ejercicioPlan);
    }
}