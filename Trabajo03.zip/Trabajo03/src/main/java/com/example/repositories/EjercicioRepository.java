package com.example.repositories;

import com.example.entities.Ejercicio;
import com.example.connectors.Connector;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EjercicioRepository {
    private Connection conn = Connector.getConnection();

    public void save(Ejercicio ejercicio) {
        if (ejercicio == null) return;
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO ejercicios (nombre, dificultad) VALUES (?, ?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, ejercicio.getNombre());
            ps.setString(2, ejercicio.getDificultad());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) ejercicio.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public void remove(Ejercicio ejercicio) {
        if (ejercicio == null) return;
        try (PreparedStatement ps = conn.prepareStatement("DELETE FROM ejercicios WHERE id=?")) {
            ps.setInt(1, ejercicio.getId());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public List<Ejercicio> getAll() {
        List<Ejercicio> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery("SELECT * FROM ejercicios")) {
            while (rs.next()) {
                list.add(new Ejercicio(
                        rs.getInt("id"),
                        rs.getString("nombre"),
                        rs.getString("dificultad")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    public Ejercicio getById(int id) {
        return getAll()
                .stream()
                .filter(e -> e.getId() == id)
                .findAny()
                .orElse(new Ejercicio());
    }
}