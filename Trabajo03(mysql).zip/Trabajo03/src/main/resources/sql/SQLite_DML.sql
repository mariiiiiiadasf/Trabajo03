-- Insertar datos en la tabla de Productos
INSERT INTO productos (nombre, precio) VALUES 
('Producto A', 19.99),
('Producto B', 29.99);

-- Insertar datos en la tabla de Categorías
INSERT INTO categorias (nombre) VALUES 
('Electrónica'),
('Ropa');