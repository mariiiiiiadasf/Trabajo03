-- Crear tabla de planes de entrenamiento
CREATE TABLE IF NOT EXISTS planes_de_entrenamiento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    descripcion TEXT,
    duracion INT
);

-- Crear tabla de ejercicios
CREATE TABLE IF NOT EXISTS ejercicios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100),
    dificultad VARCHAR(50)
);

-- Crear tabla de ejercicios_planes
CREATE TABLE IF NOT EXISTS ejercicios_planes (
    id_plan INT,
    id_ejercicio INT,
    cantidad INT,
    peso INT,
    primary key (id_plan, id_ejercicio),
    FOREIGN KEY (id_plan) REFERENCES planes_de_entrenamiento(id),
    FOREIGN KEY (id_ejercicio) REFERENCES ejercicios(id)
);