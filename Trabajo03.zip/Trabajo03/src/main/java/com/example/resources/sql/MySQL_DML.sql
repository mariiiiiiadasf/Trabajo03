-- Insertar datos en la tabla de planes de entrenamiento
use entrenamiento;
INSERT INTO planes_de_entrenamiento (nombre, descripcion, duracion) VALUES 
('Entrenamiento Básico', 'Plan básico para principiantes', 30),
('Entrenamiento Avanzado', 'Plan avanzado para expertos', 60),
('Entrenamiento de Fuerza', 'Plan enfocado en aumentar masa muscular', 45),
('Entrenamiento de Resistencia', 'Plan para mejorar la resistencia cardiovascular', 50),
('Entrenamiento HIIT', 'Entrenamiento de intervalos de alta intensidad', 30),
('Entrenamiento de Flexibilidad', 'Plan para mejorar la flexibilidad y movilidad', 20),
('Entrenamiento de Fuerza y Resistencia', 'Combinación para fuerza y resistencia', 60),
('Entrenamiento para Adelgazamiento', 'Plan para perder peso de manera efectiva', 40),
('Entrenamiento de Culturismo', 'Plan de culturismo para desarrollo muscular', 90),
('Entrenamiento Personalizado', 'Plan adaptado a necesidades individuales', 50);

-- Insertar datos en la tabla de ejercicios
INSERT INTO ejercicios (nombre, dificultad) VALUES 
('Flexiones', 'Baja'),
('Sentadillas', 'Media'),
('Dominadas', 'Alta'),
('Press de Banca', 'Alta'),
('Peso Muerto', 'Alta'),
('Abdominales', 'Baja'),
('Burpees', 'Alta'),
('Remo con Barra', 'Media'),
('Zancadas', 'Media'),
('Plancha', 'Baja');

-- Insertar datos en la tabla de ejercicios_planes
INSERT INTO ejercicios_planes (id_plan, id_ejercicio, cantidad, peso) VALUES 
(1, 1, 10, 0),  -- 10 flexiones con peso 0 para el plan básico
(1, 2, 15, 0),  -- 15 sentadillas con peso 0 para el plan básico
(2, 2, 20, 10), -- 20 sentadillas con 10 kg para el plan avanzado
(2, 3, 5, 20),  -- 5 dominadas con 20 kg para el plan avanzado
(3, 4, 8, 15),  -- 8 press de banca con 15 kg para el plan de fuerza
(3, 5, 6, 40),  -- 6 peso muerto con 40 kg para el plan de fuerza
(4, 6, 20, 0),  -- 20 abdominales sin peso para el plan de resistencia
(4, 7, 10, 10), -- 10 burpees con 10 kg para el plan de resistencia
(5, 1, 15, 0),  -- 15 flexiones 
(5, 8, 12, 15); -- 12 remo con barra con 15 kg